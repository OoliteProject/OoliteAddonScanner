#define _BUILD_STRING	__DATE__
#define _BUILD_TIME		0
#define _PRODUCTION		"libnspr4_for_oolite.a"
