// Empty for OS X, compatibility stuff for GNUstep.
