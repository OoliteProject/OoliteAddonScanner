Schemata
=======

This folder contains property list schemata for the various plists used in Oolite.

For more information, see src/Core/OXPVerifier/OOPListSchemaVerifier.h and tools/plistSchemaVerifier.
