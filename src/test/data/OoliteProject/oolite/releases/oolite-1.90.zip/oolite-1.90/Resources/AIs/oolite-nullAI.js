"use strict";
this.name = "Null AI";
// does nothing
