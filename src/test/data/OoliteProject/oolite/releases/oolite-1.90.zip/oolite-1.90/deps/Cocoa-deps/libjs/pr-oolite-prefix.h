#define _PR_PTHREADS			1
#define _PR_POLL_AVAILABLE		1
