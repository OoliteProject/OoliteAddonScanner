#ifndef BSD_STRING_H
#define BSD_STRING_H
#ifdef NEED_STRLCPY
size_t strlcpy(char *dst, const char *src, size_t siz);
#endif
#endif

